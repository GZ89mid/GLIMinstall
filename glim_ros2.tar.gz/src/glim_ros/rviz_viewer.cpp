#include <glim_ros/rviz_viewer.hpp>

#include <mutex>
#include <spdlog/spdlog.h>
#include <rclcpp/clock.hpp>

#define GLIM_ROS2
#include <gtsam/geometry/Pose3.h>
#include <gtsam_points/types/point_cloud_cpu.hpp>
#include <glim/odometry/callbacks.hpp>
#include <glim/mapping/callbacks.hpp>
#include <glim/util/logging.hpp>
#include <glim/util/config.hpp>
#include <glim/util/trajectory_manager.hpp>
#include <glim/util/ros_cloud_converter.hpp>

namespace glim {

RvizViewer::RvizViewer() : logger(create_module_logger("rviz")) {
  const Config config(GlobalConfig::get_config_path("config_ros"));

  imu_frame_id = config.param<std::string>("glim_ros", "imu_frame_id", "");
  lidar_frame_id = config.param<std::string>("glim_ros", "lidar_frame_id", "");
  base_frame_id = config.param<std::string>("glim_ros", "base_frame_id", "");
  if (base_frame_id.empty()) {
    base_frame_id = imu_frame_id;
  }

  odom_frame_id = config.param<std::string>("glim_ros", "odom_frame_id", "odom");
  map_frame_id = config.param<std::string>("glim_ros", "map_frame_id", "map");
  publish_imu2lidar = config.param<bool>("glim_ros", "publish_imu2lidar", true);
  tf_time_offset = config.param<double>("glim_ros", "tf_time_offset", 1e-6);

  last_globalmap_pub_time = rclcpp::Clock(rcl_clock_type_t::RCL_ROS_TIME).now();
  trajectory.reset(new TrajectoryManager);

  set_callbacks();

  kill_switch = false;
  thread = std::thread([this] {
    while (!kill_switch) {
      const auto expected = std::chrono::milliseconds(10);
      const auto t1 = std::chrono::high_resolution_clock::now();
      spin_once();
      const auto t2 = std::chrono::high_resolution_clock::now();

      if (t2 - t1 < expected) {
        std::this_thread::sleep_for(expected - (t2 - t1));
      }
    }
  });
}

RvizViewer::~RvizViewer() {
  kill_switch = true;
  thread.join();
}

std::vector<GenericTopicSubscription::Ptr> RvizViewer::create_subscriptions(rclcpp::Node& node) {
  tf_buffer = std::make_unique<tf2_ros::Buffer>(node.get_clock());
  tf_listener = std::make_unique<tf2_ros::TransformListener>(*tf_buffer);
  tf_broadcaster = std::make_unique<tf2_ros::TransformBroadcaster>(node);

  rmw_qos_profile_t map_qos_profile = {
    RMW_QOS_POLICY_HISTORY_KEEP_LAST,
    1,
    RMW_QOS_POLICY_RELIABILITY_RELIABLE,
    RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL,
    RMW_QOS_DEADLINE_DEFAULT,
    RMW_QOS_LIFESPAN_DEFAULT,
    RMW_QOS_POLICY_LIVELINESS_SYSTEM_DEFAULT,
    RMW_QOS_LIVELINESS_LEASE_DURATION_DEFAULT,
    false};
  rclcpp::QoS map_qos(rclcpp::QoSInitialization(map_qos_profile.history, map_qos_profile.depth), map_qos_profile);
  map_pub = node.create_publisher<sensor_msgs::msg::PointCloud2>("~/map", map_qos);

  points_pub = node.create_publisher<sensor_msgs::msg::PointCloud2>("~/points", 10);
  points_corrected_pub = node.create_publisher<sensor_msgs::msg::PointCloud2>("~/points_corrected", 10);

  aligned_points_pub = node.create_publisher<sensor_msgs::msg::PointCloud2>("~/aligned_points", 10);
  aligned_points_corrected_pub = node.create_publisher<sensor_msgs::msg::PointCloud2>("~/aligned_points_corrected", 10);

  odom_pub = node.create_publisher<nav_msgs::msg::Odometry>("~/odom", 10);
  odom_scanend_pub = node.create_publisher<nav_msgs::msg::Odometry>("~/odom_scanend", 10);
  odom_corrected_pub = node.create_publisher<nav_msgs::msg::Odometry>("~/odom_corrected", 10);
  odom_scanend_corrected_pub = node.create_publisher<nav_msgs::msg::Odometry>("~/odom_scanend_corrected", 10);

  lidar_odom_pub = node.create_publisher<nav_msgs::msg::Odometry>("~/lidar_odom", 10);
  lidar_odom_scanend_pub = node.create_publisher<nav_msgs::msg::Odometry>("~/lidar_odom_scanend", 10);
  lidar_odom_corrected_pub = node.create_publisher<nav_msgs::msg::Odometry>("~/lidar_odom_corrected", 10);
  lidar_odom_scanend_corrected_pub = node.create_publisher<nav_msgs::msg::Odometry>("~/lidar_odom_scanend_corrected", 10);

  pose_pub = node.create_publisher<geometry_msgs::msg::PoseStamped>("~/pose", 10);
  pose_scanend_pub = node.create_publisher<geometry_msgs::msg::PoseStamped>("~/pose_scanend", 10);
  pose_corrected_pub = node.create_publisher<geometry_msgs::msg::PoseStamped>("~/pose_corrected", 10);
  pose_scanend_corrected_pub = node.create_publisher<geometry_msgs::msg::PoseStamped>("~/pose_scanend_corrected", 10);
  pose_corrected_with_cov_pub = node.create_publisher<geometry_msgs::msg::PoseWithCovarianceStamped>("~/pose_corrected_with_cov", 10);
  pose_scanend_corrected_with_cov_pub = node.create_publisher<geometry_msgs::msg::PoseWithCovarianceStamped>("~/pose_scanend_corrected_with_cov", 10);

  lidar_pose_pub = node.create_publisher<geometry_msgs::msg::PoseStamped>("~/lidar_pose", 10);
  lidar_pose_scanend_pub = node.create_publisher<geometry_msgs::msg::PoseStamped>("~/lidar_pose_scanend", 10);
  lidar_pose_corrected_pub = node.create_publisher<geometry_msgs::msg::PoseStamped>("~/lidar_pose_corrected", 10);
  lidar_pose_scanend_corrected_pub = node.create_publisher<geometry_msgs::msg::PoseStamped>("~/lidar_pose_scanend_corrected", 10);
  lidar_pose_corrected_with_cov_pub = node.create_publisher<geometry_msgs::msg::PoseWithCovarianceStamped>("~/lidar_pose_corrected_with_cov", 10);
  lidar_pose_scanend_corrected_with_cov_pub = node.create_publisher<geometry_msgs::msg::PoseWithCovarianceStamped>("~/lidar_pose_scanend_corrected_with_cov", 10);

  imu_bias_pub = node.create_publisher<geometry_msgs::msg::TwistStamped>("~/imu_bias", 10);
  imu_bias_with_cov_pub = node.create_publisher<geometry_msgs::msg::TwistWithCovarianceStamped>("~/imu_bias_with_cov", 10);

  return {};
}

void RvizViewer::set_callbacks() {
  using std::placeholders::_1;
  OdometryEstimationCallbacks::on_new_frame.add([this](const EstimationFrame::ConstPtr& new_frame) { odometry_new_frame(new_frame, false); });
  OdometryEstimationCallbacks::on_update_new_frame.add([this](const EstimationFrame::ConstPtr& new_frame) { odometry_new_frame(new_frame, true); });
  GlobalMappingCallbacks::on_update_submaps.add(std::bind(&RvizViewer::globalmap_on_update_submaps, this, _1));
}

void RvizViewer::odometry_new_frame(const EstimationFrame::ConstPtr& new_frame, bool corrected) {
  const Eigen::Isometry3d T_odom_imu = new_frame->T_world_imu;
  const Eigen::Quaterniond quat_odom_imu(T_odom_imu.linear());
  const Eigen::Vector3d v_odom_imu = new_frame->v_world_imu;

  const Eigen::Isometry3d T_lidar_imu = new_frame->T_lidar_imu;
  const Eigen::Quaterniond quat_lidar_imu(T_lidar_imu.linear());
  const Eigen::Isometry3d T_imu_lidar = T_lidar_imu.inverse();

  // Covariances
  Eigen::Matrix<double, 6, 6, Eigen::RowMajor> cov_pose_imu = Eigen::Matrix<double, 6, 6, Eigen::RowMajor>::Zero();    // [x, y, z, rx, ry, rz]
  Eigen::Matrix<double, 6, 6, Eigen::RowMajor> cov_pose_lidar = Eigen::Matrix<double, 6, 6, Eigen::RowMajor>::Zero();  // [x, y, z, rx, ry, rz]

  Eigen::Matrix<double, 6, 6, Eigen::RowMajor> cov_twist = Eigen::Matrix<double, 6, 6, Eigen::RowMajor>::Zero();  // [vx, vy, vz, wx, wy, wz]
  Eigen::Matrix<double, 6, 6, Eigen::RowMajor> cov_bias = Eigen::Matrix<double, 6, 6, Eigen::RowMajor>::Zero();   // [ax, ay, az, wx, wy, wz]

  // GTSAM's marginal covariance is in the order of [rx, ry, rz, x, y, z], so we need to reorder it to [x, y, z, rx, ry, rz]
  const auto reorder_cov = [](const gtsam::Matrix6& C) {
    Eigen::Matrix<double, 6, 6, Eigen::RowMajor> cov;
    cov.block<3, 3>(0, 0) = C.block<3, 3>(3, 3);
    cov.block<3, 3>(0, 3) = C.block<3, 3>(3, 0);
    cov.block<3, 3>(3, 0) = C.block<3, 3>(0, 3);
    cov.block<3, 3>(3, 3) = C.block<3, 3>(0, 0);
    return cov;
  };

  if (new_frame->cov_computed) {
    // Transform the covariance from the IMU frame to the LiDAR frame
    const gtsam::Matrix6 C_imu = new_frame->pose_cov;

    const gtsam::Matrix6 Ad_T_lidar_imu = gtsam::Pose3(T_lidar_imu.matrix()).AdjointMap();
    const gtsam::Matrix6 C_lidar = Ad_T_lidar_imu * C_imu * Ad_T_lidar_imu.transpose();

    cov_pose_imu = reorder_cov(C_imu);
    cov_pose_lidar = reorder_cov(C_lidar);

    cov_twist.block<3, 3>(0, 0) = new_frame->vel_cov;
    cov_bias = new_frame->bias_cov;
  }

  if (imu_frame_id.empty()) {
    imu_frame_id = GlobalConfig::instance()->param<std::string>("meta", "imu_frame_id", "");
    if (imu_frame_id.empty()) {
      logger->warn("IMU frame ID is not set. Using 'imu' as default.");
      imu_frame_id = "imu";
    } else {
      logger->info("auto-detected IMU frame ID: {}", imu_frame_id);
    }
  }

  if (lidar_frame_id.empty()) {
    lidar_frame_id = GlobalConfig::instance()->param<std::string>("meta", "lidar_frame_id", "");
    if (lidar_frame_id.empty()) {
      logger->warn("LiDAR frame ID is not set. Using 'lidar' as default.");
      lidar_frame_id = "lidar";
    } else {
      logger->info("auto-detected LiDAR frame ID: {}", lidar_frame_id);
    }
  }

  if (base_frame_id.empty()) {
    base_frame_id = imu_frame_id;
    logger->info("base_frame_id is not set. using IMU frame ID '{}' as base frame ID.", imu_frame_id);
  }

  // Poses at the end of the scan
  double imu_end_time = new_frame->stamp;
  Eigen::Isometry3d T_imubegin_imuend = Eigen::Isometry3d::Identity();
  if (new_frame->imu_rate_trajectory.size()) {
    const Eigen::Matrix<double, 8, 1> imu_begin = new_frame->imu_rate_trajectory.col(0);
    const Eigen::Matrix<double, 8, 1> imu_end = new_frame->imu_rate_trajectory.col(new_frame->imu_rate_trajectory.cols() - 1);

    Eigen::Isometry3d T_odom_imubegin = Eigen::Isometry3d::Identity();
    T_odom_imubegin.translation() = imu_begin.segment<3>(1);
    T_odom_imubegin.linear() = Eigen::Quaterniond(imu_begin(7), imu_begin(4), imu_begin(5), imu_begin(6)).toRotationMatrix();

    Eigen::Isometry3d T_odom_imuend = Eigen::Isometry3d::Identity();
    T_odom_imuend.translation() = imu_end.segment<3>(1);
    T_odom_imuend.linear() = Eigen::Quaterniond(imu_end(7), imu_end(4), imu_end(5), imu_end(6)).toRotationMatrix();

    T_imubegin_imuend = T_odom_imubegin.inverse() * T_odom_imuend;
    imu_end_time = imu_end(0);
  }

  Eigen::Isometry3d T_world_odom;
  Eigen::Quaterniond quat_world_odom;

  Eigen::Isometry3d T_world_imu;
  Eigen::Quaterniond quat_world_imu;

  {
    // Transform the odometry frame to the global optimization-based world frame
    std::lock_guard<std::mutex> lock(trajectory_mutex);
    trajectory->add_odom(new_frame->stamp, new_frame->T_world_imu, 1);
    T_world_odom = trajectory->get_T_world_odom();
    quat_world_odom = Eigen::Quaterniond(T_world_odom.linear());

    T_world_imu = trajectory->odom2world(T_odom_imu);
    quat_world_imu = Eigen::Quaterniond(T_world_imu.linear());
  }

  // Publish transforms
  const auto stamp = from_sec(new_frame->stamp);
  const auto tf_stamp = from_sec(new_frame->stamp + tf_time_offset);
  const auto imu_end_stamp = from_sec(imu_end_time);

  const bool publish_tf = !corrected;
  if (publish_tf) {
    // Odom -> Base
    geometry_msgs::msg::TransformStamped trans;
    trans.header.stamp = tf_stamp;
    trans.header.frame_id = odom_frame_id;
    trans.child_frame_id = base_frame_id;

    if (base_frame_id == imu_frame_id) {
      trans.transform.translation.x = T_odom_imu.translation().x();
      trans.transform.translation.y = T_odom_imu.translation().y();
      trans.transform.translation.z = T_odom_imu.translation().z();
      trans.transform.rotation.x = quat_odom_imu.x();
      trans.transform.rotation.y = quat_odom_imu.y();
      trans.transform.rotation.z = quat_odom_imu.z();
      trans.transform.rotation.w = quat_odom_imu.w();
      tf_broadcaster->sendTransform(trans);
    } else {
      try {
        const auto trans_imu_base = tf_buffer->lookupTransform(imu_frame_id, base_frame_id, from_sec(new_frame->stamp));
        const auto& t = trans_imu_base.transform.translation;
        const auto& r = trans_imu_base.transform.rotation;

        Eigen::Isometry3d T_imu_base = Eigen::Isometry3d::Identity();
        T_imu_base.translation() << t.x, t.y, t.z;
        T_imu_base.linear() = Eigen::Quaterniond(r.w, r.x, r.y, r.z).toRotationMatrix();

        const Eigen::Isometry3d T_odom_base = T_odom_imu * T_imu_base;
        const Eigen::Quaterniond quat_odom_base(T_odom_base.linear());

        trans.transform.translation.x = T_odom_base.translation().x();
        trans.transform.translation.y = T_odom_base.translation().y();
        trans.transform.translation.z = T_odom_base.translation().z();
        trans.transform.rotation.x = quat_odom_base.x();
        trans.transform.rotation.y = quat_odom_base.y();
        trans.transform.rotation.z = quat_odom_base.z();
        trans.transform.rotation.w = quat_odom_base.w();
        tf_broadcaster->sendTransform(trans);
      } catch (const tf2::TransformException& e) {
        logger->warn("Failed to lookup transform from {} to {} (stamp={}.{}): {}", imu_frame_id, base_frame_id, stamp.sec, stamp.nanosec, e.what());
      }
    }

    // World -> Odom
    trans.header.frame_id = map_frame_id;
    trans.child_frame_id = odom_frame_id;
    trans.transform.translation.x = T_world_odom.translation().x();
    trans.transform.translation.y = T_world_odom.translation().y();
    trans.transform.translation.z = T_world_odom.translation().z();
    trans.transform.rotation.x = quat_world_odom.x();
    trans.transform.rotation.y = quat_world_odom.y();
    trans.transform.rotation.z = quat_world_odom.z();
    trans.transform.rotation.w = quat_world_odom.w();
    tf_broadcaster->sendTransform(trans);

    // IMU -> LiDAR
    if (publish_imu2lidar) {
      trans.header.frame_id = imu_frame_id;
      trans.child_frame_id = lidar_frame_id;
      trans.transform.translation.x = T_lidar_imu.translation().x();
      trans.transform.translation.y = T_lidar_imu.translation().y();
      trans.transform.translation.z = T_lidar_imu.translation().z();
      trans.transform.rotation.x = quat_lidar_imu.x();
      trans.transform.rotation.y = quat_lidar_imu.y();
      trans.transform.rotation.z = quat_lidar_imu.z();
      trans.transform.rotation.w = quat_lidar_imu.w();
      tf_broadcaster->sendTransform(trans);
    }
  }

  const auto convert_to_lidar_odom = [&](const nav_msgs::msg::Odometry& odom) {
    const auto& imu_pos = odom.pose.pose.position;
    const auto& imu_ori = odom.pose.pose.orientation;
    Eigen::Isometry3d T_odom_imu = Eigen::Isometry3d::Identity();
    T_odom_imu.translation() << imu_pos.x, imu_pos.y, imu_pos.z;
    T_odom_imu.linear() = Eigen::Quaterniond(imu_ori.w, imu_ori.x, imu_ori.y, imu_ori.z).toRotationMatrix();

    const Eigen::Isometry3d T_odom_lidar = T_odom_imu * T_imu_lidar;
    const Eigen::Vector3d lidar_pos = T_odom_lidar.translation();
    const Eigen::Quaterniond lidar_ori(T_odom_lidar.linear());

    nav_msgs::msg::Odometry lidar_odom = odom;
    lidar_odom.child_frame_id = lidar_frame_id;
    lidar_odom.pose.pose.position.x = lidar_pos.x();
    lidar_odom.pose.pose.position.y = lidar_pos.y();
    lidar_odom.pose.pose.position.z = lidar_pos.z();
    lidar_odom.pose.pose.orientation.x = lidar_ori.x();
    lidar_odom.pose.pose.orientation.y = lidar_ori.y();
    lidar_odom.pose.pose.orientation.z = lidar_ori.z();
    lidar_odom.pose.pose.orientation.w = lidar_ori.w();

    if (new_frame->cov_computed) {
      std::copy(cov_pose_lidar.data(), cov_pose_lidar.data() + 36, lidar_odom.pose.covariance.begin());
      std::copy(cov_twist.data(), cov_twist.data() + 36, lidar_odom.twist.covariance.begin());
    }

    return lidar_odom;
  };

  const auto convert_to_lidar_pose = [&](const geometry_msgs::msg::PoseStamped& pose) {
    const auto& imu_pos = pose.pose.position;
    const auto& imu_ori = pose.pose.orientation;
    Eigen::Isometry3d T_world_imu = Eigen::Isometry3d::Identity();
    T_world_imu.translation() << imu_pos.x, imu_pos.y, imu_pos.z;
    T_world_imu.linear() = Eigen::Quaterniond(imu_ori.w, imu_ori.x, imu_ori.y, imu_ori.z).toRotationMatrix();

    const Eigen::Isometry3d T_world_lidar = T_world_imu * T_imu_lidar;
    const Eigen::Vector3d lidar_pos = T_world_lidar.translation();
    const Eigen::Quaterniond lidar_ori(T_world_lidar.linear());

    geometry_msgs::msg::PoseStamped lidar_pose = pose;
    lidar_pose.pose.position.x = lidar_pos.x();
    lidar_pose.pose.position.y = lidar_pos.y();
    lidar_pose.pose.position.z = lidar_pos.z();
    lidar_pose.pose.orientation.x = lidar_ori.x();
    lidar_pose.pose.orientation.y = lidar_ori.y();
    lidar_pose.pose.orientation.z = lidar_ori.z();
    lidar_pose.pose.orientation.w = lidar_ori.w();

    return lidar_pose;
  };

  auto& odom_pub = !corrected ? this->odom_pub : this->odom_corrected_pub;
  auto& lidar_odom_pub = !corrected ? this->lidar_odom_pub : this->lidar_odom_corrected_pub;
  if (odom_pub->get_subscription_count() || lidar_odom_pub->get_subscription_count()) {
    // Publish sensor pose (without loop closure)
    nav_msgs::msg::Odometry odom;
    odom.header.stamp = stamp;
    odom.header.frame_id = odom_frame_id;
    odom.child_frame_id = imu_frame_id;
    odom.pose.pose.position.x = T_odom_imu.translation().x();
    odom.pose.pose.position.y = T_odom_imu.translation().y();
    odom.pose.pose.position.z = T_odom_imu.translation().z();
    odom.pose.pose.orientation.x = quat_odom_imu.x();
    odom.pose.pose.orientation.y = quat_odom_imu.y();
    odom.pose.pose.orientation.z = quat_odom_imu.z();
    odom.pose.pose.orientation.w = quat_odom_imu.w();

    odom.twist.twist.linear.x = v_odom_imu.x();
    odom.twist.twist.linear.y = v_odom_imu.y();
    odom.twist.twist.linear.z = v_odom_imu.z();

    if (new_frame->cov_computed) {
      std::copy(cov_pose_imu.data(), cov_pose_imu.data() + 36, odom.pose.covariance.begin());
      std::copy(cov_twist.data(), cov_twist.data() + 36, odom.twist.covariance.begin());
    }

    if (odom_pub->get_subscription_count()) {
      odom_pub->publish(odom);
      logger->debug("published odom (stamp={})", new_frame->stamp);
    }
    if (lidar_odom_pub->get_subscription_count()) {
      lidar_odom_pub->publish(convert_to_lidar_odom(odom));
      logger->debug("published lidar_odom (stamp={})", new_frame->stamp);
    }
  }

  auto& odom_scan_end_pub = !corrected ? this->odom_scanend_pub : this->odom_scanend_corrected_pub;
  auto& lidar_odom_scan_end_pub = !corrected ? this->lidar_odom_scanend_pub : this->lidar_odom_scanend_corrected_pub;
  if (odom_scan_end_pub->get_subscription_count() || lidar_odom_scan_end_pub->get_subscription_count()) {
    // Publish sensor pose at the end of the scan (without loop closure)
    if (std::abs(imu_end_time - new_frame->stamp) < 1e-3) {
      logger->warn("Scan end time is too close to the frame time (imu_end_time={}, frame_time={})", imu_end_time, new_frame->stamp);
      logger->warn("Possibly due to the lack of IMU data");
    }

    const Eigen::Isometry3d T_odom_imuend = T_odom_imu * T_imubegin_imuend;
    const Eigen::Quaterniond quat_odom_imuend(T_odom_imuend.linear());

    nav_msgs::msg::Odometry odom;
    odom.header.stamp = imu_end_stamp;
    odom.header.frame_id = odom_frame_id;
    odom.child_frame_id = imu_frame_id;
    odom.pose.pose.position.x = T_odom_imuend.translation().x();
    odom.pose.pose.position.y = T_odom_imuend.translation().y();
    odom.pose.pose.position.z = T_odom_imuend.translation().z();
    odom.pose.pose.orientation.x = quat_odom_imuend.x();
    odom.pose.pose.orientation.y = quat_odom_imuend.y();
    odom.pose.pose.orientation.z = quat_odom_imuend.z();
    odom.pose.pose.orientation.w = quat_odom_imuend.w();

    odom.twist.twist.linear.x = v_odom_imu.x();
    odom.twist.twist.linear.y = v_odom_imu.y();
    odom.twist.twist.linear.z = v_odom_imu.z();

    if (odom_scan_end_pub->get_subscription_count()) {
      odom_scan_end_pub->publish(odom);
      logger->debug("published odom_scanend (scanend_stamp={})", imu_end_time);
    }
    if (lidar_odom_scan_end_pub->get_subscription_count()) {
      lidar_odom_scan_end_pub->publish(convert_to_lidar_odom(odom));
      logger->debug("published lidar_odom_scanend (scanend_stamp={})", imu_end_time);
    }
  }

  auto& pose_pub = !corrected ? this->pose_pub : this->pose_corrected_pub;
  auto& lidar_pose_pub = !corrected ? this->lidar_pose_pub : this->lidar_pose_corrected_pub;
  // Covariance topics exist only for the corrected estimates
  const bool publish_pose_with_cov = corrected && pose_corrected_with_cov_pub->get_subscription_count();
  const bool publish_lidar_pose_with_cov = corrected && lidar_pose_corrected_with_cov_pub->get_subscription_count();
  if (
    pose_pub->get_subscription_count() ||        //
    lidar_pose_pub->get_subscription_count() ||  //
    publish_pose_with_cov ||                     //
    publish_lidar_pose_with_cov                  //
  ) {
    // Publish sensor pose (with loop closure)
    geometry_msgs::msg::PoseStamped pose;
    pose.header.stamp = stamp;
    pose.header.frame_id = map_frame_id;
    pose.pose.position.x = T_world_imu.translation().x();
    pose.pose.position.y = T_world_imu.translation().y();
    pose.pose.position.z = T_world_imu.translation().z();
    pose.pose.orientation.x = quat_world_imu.x();
    pose.pose.orientation.y = quat_world_imu.y();
    pose.pose.orientation.z = quat_world_imu.z();
    pose.pose.orientation.w = quat_world_imu.w();

    if (pose_pub->get_subscription_count()) {
      pose_pub->publish(pose);
      logger->debug("published pose (stamp={})", new_frame->stamp);
    }
    if (publish_pose_with_cov) {
      geometry_msgs::msg::PoseWithCovarianceStamped pose_with_cov;
      pose_with_cov.header = pose.header;
      pose_with_cov.pose.pose = pose.pose;
      std::copy(cov_pose_imu.data(), cov_pose_imu.data() + 36, pose_with_cov.pose.covariance.begin());
      pose_corrected_with_cov_pub->publish(pose_with_cov);
      logger->debug("published pose_with_cov (stamp={})", new_frame->stamp);
    }

    if (lidar_pose_pub->get_subscription_count()) {
      lidar_pose_pub->publish(convert_to_lidar_pose(pose));
      logger->debug("published lidar_pose (stamp={})", new_frame->stamp);
    }
    if (publish_lidar_pose_with_cov) {
      geometry_msgs::msg::PoseWithCovarianceStamped lidar_pose_with_cov;
      lidar_pose_with_cov.header = pose.header;
      lidar_pose_with_cov.pose.pose = convert_to_lidar_pose(pose).pose;
      std::copy(cov_pose_lidar.data(), cov_pose_lidar.data() + 36, lidar_pose_with_cov.pose.covariance.begin());
      lidar_pose_corrected_with_cov_pub->publish(lidar_pose_with_cov);
      logger->debug("published lidar_pose_with_cov (stamp={})", new_frame->stamp);
    }
  }

  auto& pose_scan_end_pub = !corrected ? this->pose_scanend_pub : this->pose_scanend_corrected_pub;
  auto& lidar_pose_scan_end_pub = !corrected ? this->lidar_pose_scanend_pub : this->lidar_pose_scanend_corrected_pub;
  // Covariance topics exist only for the corrected estimates
  const bool publish_pose_scanend_with_cov = corrected && pose_scanend_corrected_with_cov_pub->get_subscription_count();
  const bool publish_lidar_pose_scanend_with_cov = corrected && lidar_pose_scanend_corrected_with_cov_pub->get_subscription_count();
  if (
    pose_scan_end_pub->get_subscription_count() ||        //
    lidar_pose_scan_end_pub->get_subscription_count() ||  //
    publish_pose_scanend_with_cov ||                      //
    publish_lidar_pose_scanend_with_cov                   //
  ) {
    // Publish sensor pose at the end of the scan (with loop closure)
    if (std::abs(imu_end_time - new_frame->stamp) < 1e-3) {
      logger->warn("Scan end time is too close to the frame time (imu_end_time={}, frame_time={})", imu_end_time, new_frame->stamp);
      logger->warn("Possibly due to the lack of IMU data");
    }

    const Eigen::Isometry3d T_world_imuend = T_world_imu * T_imubegin_imuend;
    const Eigen::Quaterniond quat_world_imuend(T_world_imuend.linear());

    geometry_msgs::msg::PoseStamped pose;
    pose.header.stamp = imu_end_stamp;
    pose.header.frame_id = map_frame_id;
    pose.pose.position.x = T_world_imuend.translation().x();
    pose.pose.position.y = T_world_imuend.translation().y();
    pose.pose.position.z = T_world_imuend.translation().z();
    pose.pose.orientation.x = quat_world_imuend.x();
    pose.pose.orientation.y = quat_world_imuend.y();
    pose.pose.orientation.z = quat_world_imuend.z();
    pose.pose.orientation.w = quat_world_imuend.w();

    if (pose_scan_end_pub->get_subscription_count()) {
      pose_scan_end_pub->publish(pose);
      logger->debug("published pose_scanend (scanend_stamp={})", imu_end_time);
    }
    if (lidar_pose_scan_end_pub->get_subscription_count()) {
      lidar_pose_scan_end_pub->publish(convert_to_lidar_pose(pose));
      logger->debug("published lidar_pose_scanend (scanend_stamp={})", imu_end_time);
    }

    if (publish_pose_scanend_with_cov || publish_lidar_pose_scanend_with_cov) {
      // Transform the covariance to the scan-end pose (T_world_imuend = T_world_imu * T_imubegin_imuend)
      const gtsam::Matrix6 Ad_T_imuend_imubegin = gtsam::Pose3(T_imubegin_imuend.inverse().matrix()).AdjointMap();
      const gtsam::Matrix6 C_imuend = Ad_T_imuend_imubegin * new_frame->pose_cov * Ad_T_imuend_imubegin.transpose();

      if (publish_pose_scanend_with_cov) {
        geometry_msgs::msg::PoseWithCovarianceStamped pose_with_cov;
        pose_with_cov.header = pose.header;
        pose_with_cov.pose.pose = pose.pose;
        const auto cov_pose_imuend = reorder_cov(C_imuend);
        std::copy(cov_pose_imuend.data(), cov_pose_imuend.data() + 36, pose_with_cov.pose.covariance.begin());
        pose_scanend_corrected_with_cov_pub->publish(pose_with_cov);
        logger->debug("published pose_scanend_with_cov (scanend_stamp={})", imu_end_time);
      }
      if (publish_lidar_pose_scanend_with_cov) {
        const gtsam::Matrix6 Ad_T_lidar_imu = gtsam::Pose3(T_lidar_imu.matrix()).AdjointMap();
        const gtsam::Matrix6 C_lidarend = Ad_T_lidar_imu * C_imuend * Ad_T_lidar_imu.transpose();

        geometry_msgs::msg::PoseWithCovarianceStamped lidar_pose_with_cov;
        lidar_pose_with_cov.header = pose.header;
        lidar_pose_with_cov.pose.pose = convert_to_lidar_pose(pose).pose;
        const auto cov_pose_lidarend = reorder_cov(C_lidarend);
        std::copy(cov_pose_lidarend.data(), cov_pose_lidarend.data() + 36, lidar_pose_with_cov.pose.covariance.begin());
        lidar_pose_scanend_corrected_with_cov_pub->publish(lidar_pose_with_cov);
        logger->debug("published lidar_pose_scanend_with_cov (scanend_stamp={})", imu_end_time);
      }
    }
  }

  if (corrected && (imu_bias_pub->get_subscription_count() || imu_bias_with_cov_pub->get_subscription_count())) {
    // Publish IMU bias
    geometry_msgs::msg::TwistStamped bias;
    bias.header.stamp = stamp;
    bias.header.frame_id = imu_frame_id;
    bias.twist.linear.x = new_frame->imu_bias(0);
    bias.twist.linear.y = new_frame->imu_bias(1);
    bias.twist.linear.z = new_frame->imu_bias(2);
    bias.twist.angular.x = new_frame->imu_bias(3);
    bias.twist.angular.y = new_frame->imu_bias(4);
    bias.twist.angular.z = new_frame->imu_bias(5);

    if (imu_bias_pub->get_subscription_count()) {
      imu_bias_pub->publish(bias);
      logger->debug("published imu_bias (stamp={})", new_frame->stamp);
    }
    if (imu_bias_with_cov_pub->get_subscription_count()) {
      geometry_msgs::msg::TwistWithCovarianceStamped bias_with_cov;
      bias_with_cov.header = bias.header;
      bias_with_cov.twist.twist = bias.twist;
      std::copy(cov_bias.data(), cov_bias.data() + 36, bias_with_cov.twist.covariance.begin());
      imu_bias_with_cov_pub->publish(bias_with_cov);
      logger->debug("published imu_bias_with_cov (stamp={})", new_frame->stamp);
    }
  }

  auto& points_pub = !corrected ? this->points_pub : this->points_corrected_pub;
  if (points_pub->get_subscription_count()) {
    // Publish points in their own coordinate frame
    std::string frame_id;
    switch (new_frame->frame_id) {
      case FrameID::LIDAR:
        frame_id = lidar_frame_id;
        break;
      case FrameID::IMU:
        frame_id = imu_frame_id;
        break;
      case FrameID::WORLD:
        frame_id = map_frame_id;
        break;
    }

    auto points = frame_to_pointcloud2(frame_id, new_frame->stamp, *new_frame->frame);
    points_pub->publish(*points);

    logger->debug("published points (stamp={} num_points={})", new_frame->stamp, new_frame->frame->size());
  }

  auto& aligned_points_pub = !corrected ? this->aligned_points_pub : this->aligned_points_corrected_pub;
  if (aligned_points_pub->get_subscription_count()) {
    // Publish points aligned to the world frame to avoid some visualization issues in Rviz2
    std::vector<Eigen::Vector4d> transformed(new_frame->frame->size());
    for (int i = 0; i < new_frame->frame->size(); i++) {
      transformed[i] = new_frame->T_world_sensor() * new_frame->frame->points[i];
    }

    gtsam_points::PointCloud frame;
    frame.num_points = new_frame->frame->size();
    frame.points = transformed.data();
    frame.times = new_frame->frame->times;
    frame.intensities = new_frame->frame->intensities;

    auto points = frame_to_pointcloud2(map_frame_id, new_frame->stamp, frame);
    aligned_points_pub->publish(*points);

    logger->debug("published aligned_points (stamp={} num_points={})", new_frame->stamp, frame.size());
  }
}

void RvizViewer::globalmap_on_update_submaps(const std::vector<SubMap::Ptr>& submaps) {
  const SubMap::ConstPtr latest_submap = submaps.back();

  const double stamp_endpoint_R = latest_submap->odom_frames.back()->stamp;
  const Eigen::Isometry3d T_world_endpoint_R = latest_submap->T_world_origin * latest_submap->T_origin_endpoint_R;
  {
    std::lock_guard<std::mutex> lock(trajectory_mutex);
    trajectory->update_anchor(stamp_endpoint_R, T_world_endpoint_R);
  }

  std::vector<Eigen::Isometry3d, Eigen::aligned_allocator<Eigen::Isometry3d>> submap_poses(submaps.size());
  for (int i = 0; i < submaps.size(); i++) {
    submap_poses[i] = submaps[i]->T_world_origin;
  }

  // Invoke a submap concatenation task in the RvizViewer thread
  invoke([this, latest_submap, submap_poses] {
    // on_update_submaps also fires from GlobalMapping::optimize(), which runs periodically while
    // the input queues are idle and adds no submap. Appending unconditionally would then push the
    // same last submap again and again, growing this->submaps past submap_poses and making the
    // indexed lookup below read out of bounds. Only append when a submap was actually added.
    if (this->submaps.size() < submap_poses.size()) {
      this->submaps.push_back(latest_submap->frame);
    }

    if (!map_pub->get_subscription_count()) {
      return;
    }

    // Publish global map every 10 seconds
    const rclcpp::Time now = rclcpp::Clock(rcl_clock_type_t::RCL_ROS_TIME).now();
    if (now - last_globalmap_pub_time < std::chrono::seconds(10)) {
      return;
    }
    last_globalmap_pub_time = now;

    logger->warn("Publishing global map is computationally demanding and not recommended");

    int total_num_points = 0;
    for (const auto& submap : this->submaps) {
      total_num_points += submap->size();
    }

    // Concatenate all the submap points
    gtsam_points::PointCloudCPU::Ptr merged(new gtsam_points::PointCloudCPU);
    merged->num_points = total_num_points;
    merged->points_storage.resize(total_num_points);
    merged->points = merged->points_storage.data();

    int begin = 0;
    for (int i = 0; i < this->submaps.size(); i++) {
      const auto& submap = this->submaps[i];
      std::transform(submap->points, submap->points + submap->size(), merged->points + begin, [&](const Eigen::Vector4d& p) { return submap_poses[i] * p; });
      begin += submap->size();
    }

    auto points_msg = frame_to_pointcloud2(map_frame_id, now.seconds(), *merged);
    map_pub->publish(*points_msg);
  });
}

void RvizViewer::invoke(const std::function<void()>& task) {
  std::lock_guard<std::mutex> lock(invoke_queue_mutex);
  invoke_queue.push_back(task);
}

void RvizViewer::spin_once() {
  std::vector<std::function<void()>> invoke_queue;

  {
    std::lock_guard<std::mutex> lock(invoke_queue_mutex);
    invoke_queue.swap(this->invoke_queue);
  }

  for (const auto& task : invoke_queue) {
    task();
  }
}

}  // namespace glim

extern "C" glim::ExtensionModule* create_extension_module() {
  return new glim::RvizViewer();
}